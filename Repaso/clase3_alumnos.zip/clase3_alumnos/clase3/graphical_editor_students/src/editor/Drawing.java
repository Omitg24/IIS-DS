package editor;

public class Drawing 
{
	public void draw()
	{
		System.out.println("Estoy vacío (por ahora)");
	}
}
