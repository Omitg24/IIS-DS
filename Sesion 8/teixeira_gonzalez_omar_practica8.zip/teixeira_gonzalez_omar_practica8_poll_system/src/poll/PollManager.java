package poll;

/**
 * Titulo: Clase PollsManagement
 *
 * @author Omar Teixeira González, UO281847
 * @version 7 nov 2022
 */
public interface PollManager {
	/**
	 * Método manage
	 * @param poll
	 */
	void manage(Poll poll);
}
