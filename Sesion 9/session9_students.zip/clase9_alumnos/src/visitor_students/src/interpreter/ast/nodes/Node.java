package interpreter.ast.nodes;

public interface Node
{
}
