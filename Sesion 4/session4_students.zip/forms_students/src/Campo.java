
public interface Campo {
	public void pideDato();
	public String getString();
}
