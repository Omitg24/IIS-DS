package slides.content;

import slides.ui.Canvas;

public interface Placeholder
{
    void edit(Canvas canvas);
    void paint(Canvas canvas);
}