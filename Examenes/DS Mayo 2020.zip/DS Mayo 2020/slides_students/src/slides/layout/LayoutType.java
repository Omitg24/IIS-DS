package slides.layout;

public enum LayoutType 
{
    NORMAL, COLUMNS, GRID;
}