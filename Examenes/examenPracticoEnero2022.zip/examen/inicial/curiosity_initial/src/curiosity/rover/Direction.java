package curiosity.rover;

public enum Direction {
	NORTH, EAST, SOUTH, WEST
}
