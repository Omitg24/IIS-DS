package photos.ui;

public class UserInputException extends Exception
{
	private static final long serialVersionUID = 1L;

	public UserInputException(String message)
	{
		super(message);
	}
}
