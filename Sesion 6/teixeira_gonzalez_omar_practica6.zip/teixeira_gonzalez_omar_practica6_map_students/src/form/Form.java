package form;

/**
 * Titulo: Clase Form
 * Formulario básico para usar cuando se quieran pedir sólo dos valores sobre algo.
 *
 * @author Omar Teixeira González, UO281847
 * @version 30 oct 2022
 */
public class Form {

	/**
	 * Método edit
	 * @param editPlace
	 */
	public void edit(EditPlace editPlace) 
	{
		editPlace.edit();
	}	
}
