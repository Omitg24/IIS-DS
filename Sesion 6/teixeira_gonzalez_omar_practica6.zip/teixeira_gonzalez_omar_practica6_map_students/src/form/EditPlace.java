package form;

/**
 * Titulo: Interfaz EditPlace
 *
 * @author Omar Teixeira González, UO281847
 * @version 30 oct 2022
 */
public interface EditPlace {
	/**
	 * Método edit
	 * @param editPlace
	 */
	void edit();
	
	/**
	 * Método print
	 * @param editPlace
	 */
	void print();
}
